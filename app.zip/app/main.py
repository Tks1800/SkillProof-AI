from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import skill_test
from app.database import Base, engine
from app.models_new import (
    User,
    Resume,
    Job,
    Company,
    CandidateProfile,
    CandidateSkill,
    Skill,
    Question,
    TestResult,
    InterviewInvitation,
    Application,
)

from app.routers import (
    auth,
    candidate,
    recruiter,
    resume,
    interview,
    dashboard,
    jobs,
    application,
    candidate_profile,
    ai_match,
)


Base.metadata.create_all(bind=engine)

app = FastAPI(debug=True)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://skill-proof-ai-ffy2.vercel.app",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
        "http://localhost:5175",
        "http://127.0.0.1:5175",
        "http://localhost:5176",
        "http://127.0.0.1:5176",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(candidate.router)
app.include_router(recruiter.router)
app.include_router(resume.router)
app.include_router(interview.router)
app.include_router(dashboard.router)
app.include_router(jobs.router)
app.include_router(application.router)
app.include_router(candidate_profile.router)
app.include_router(ai_match.router)
app.include_router(skill_test.router)


@app.get("/")
def home():
    return {"message": "SkillProof AI Running"}
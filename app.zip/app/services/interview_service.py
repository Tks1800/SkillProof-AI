from sqlalchemy.orm import Session

from app.models_new.interview import InterviewInvitation
from app.schemas import InterviewCreate


class InterviewService:

    @staticmethod
    def create_interview(db: Session, data: InterviewCreate):

        interview = InterviewInvitation(
            recruiter_email=data.recruiter_email,
            candidate_email=data.candidate_email,
            job_id=data.job_id,
            scheduled_at=data.scheduled_at,
            meeting_link=data.meeting_link,
            interview_type=data.interview_type,
            notes=data.notes,
            status="Pending"
        )

        db.add(interview)
        db.commit()
        db.refresh(interview)

        return interview

    @staticmethod
    def get_candidate_interviews(
        db: Session,
        candidate_email: str
    ):
        return (
            db.query(InterviewInvitation)
            .filter(
                InterviewInvitation.candidate_email
                == candidate_email
            )
            .all()
        )

    @staticmethod
    def get_recruiter_interviews(
        db: Session,
        recruiter_email: str
    ):
        return (
            db.query(InterviewInvitation)
            .filter(
                InterviewInvitation.recruiter_email
                == recruiter_email
            )
            .all()
        )

    @staticmethod
    def accept_interview(
        db: Session,
        interview_id: int
    ):

        interview = (
            db.query(InterviewInvitation)
            .filter(
                InterviewInvitation.id == interview_id
            )
            .first()
        )

        if not interview:
            return None

        interview.status = "Accepted"

        db.commit()
        db.refresh(interview)

        return interview

    @staticmethod
    def reject_interview(
        db: Session,
        interview_id: int
    ):

        interview = (
            db.query(InterviewInvitation)
            .filter(
                InterviewInvitation.id == interview_id
            )
            .first()
        )

        if not interview:
            return None

        interview.status = "Rejected"

        db.commit()
        db.refresh(interview)

        return interview
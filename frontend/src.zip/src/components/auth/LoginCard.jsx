import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import InputField from "../common/InputField";
import PrimaryButton from "../common/PrimaryButton";
import API from "../../services/api";

export default function LoginCard() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleLogin = async () => {
    try {
        const res = await API.post("/auth/login", form);

        console.log(res.data);

        localStorage.setItem("token", res.data.access_token);
        localStorage.setItem("user", JSON.stringify(res.data));

        navigate("/dashboard");
  }     catch (err) {
        console.log(err.response?.data);
        alert(err.response?.data?.detail || "Login Failed");
  }
};

  return (
    <>
      <h2 className="text-3xl font-bold text-white">
        Welcome Back 👋
      </h2>

      <p className="text-gray-400 mt-2 mb-8">
        Verify Skills. Build Trust. Get Hired.
      </p>

      <div className="space-y-5">

        <InputField
          label="Email"
          name="email"
          type="email"
          placeholder="Enter your email"
          value={form.email}
          onChange={handleChange}
        />

        <InputField
          label="Password"
          name="password"
          type="password"
          placeholder="Enter your password"
          value={form.password}
          onChange={handleChange}
        />

        <PrimaryButton onClick={handleLogin}>
          Login
        </PrimaryButton>

      </div>

      <p className="text-center text-gray-400 mt-8">
        Don't have an account?

        <Link
          to="/register"
          className="ml-2 text-cyan-400"
        >
          Create Account
        </Link>
      </p>
    </>
  );
}
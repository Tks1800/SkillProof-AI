import { useState } from "react";
import API from "../../services/api";

export default function ResumeUpload() {
  const [file, setFile] = useState(null);

  async function uploadResume() {
    if (!file) {
      alert("Please select a PDF first.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    const token = localStorage.getItem("token");

    try {
      const res = await API.post(
        "/resume/upload",
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      console.log(res.data);
      alert("Resume Uploaded Successfully!");

    } catch (err) {
      console.error(err);
      alert("Upload Failed");
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#070B1A",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <div
        style={{
          width: "500px",
          background: "#151927",
          padding: "40px",
          borderRadius: "20px",
        }}
      >
        <h1
          style={{
            color: "white",
            fontSize: "32px",
            marginBottom: "30px",
          }}
        >
          Upload Resume
        </h1>

        <input
          type="file"
          accept=".pdf"
          onChange={(e) => {
            console.log("FILES:", e.target.files);
            console.log("FILE:", e.target.files[0]);

            if (e.target.files.length > 0) {
              setFile(e.target.files[0]);
            }
          }}
        />

        <br />
        <br />

        {file && (
          <p style={{ color: "white" }}>
            Selected File: {file.name}
          </p>
        )}

        <button
          onClick={uploadResume}
          style={{
            marginTop: "20px",
            width: "100%",
            padding: "15px",
            background: "#00C2FF",
            color: "white",
            border: "none",
            borderRadius: "10px",
            cursor: "pointer",
            fontSize: "18px",
          }}
        >
          Upload Resume
        </button>
      </div>
    </div>
  );
}
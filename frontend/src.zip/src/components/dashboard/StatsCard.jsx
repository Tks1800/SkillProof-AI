export default function StatsCard({
  title,
  value,
  color = "text-cyan-400",
}) {
  return (
    <div className="bg-[#151927] rounded-2xl p-6 border border-white/10">
      <p className="text-gray-400">{title}</p>

      <h2 className={`text-4xl font-bold mt-3 ${color}`}>
        {value}
      </h2>
    </div>
  );
}
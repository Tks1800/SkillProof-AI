import DashboardLayout from "../layouts/DashboardLayout";

export default function CandidateDashboard() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-4xl font-bold">Candidate Dashboard</h1>
          <p className="text-gray-400 mt-2">
            Welcome back! Track your applications and certifications.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-[#111827] rounded-2xl p-6 border border-gray-800">
            <h3 className="text-gray-400">Applications</h3>
            <p className="text-4xl font-bold mt-3">0</p>
          </div>

          <div className="bg-[#111827] rounded-2xl p-6 border border-gray-800">
            <h3 className="text-gray-400">Badges</h3>
            <p className="text-4xl font-bold mt-3">0</p>
          </div>

          <div className="bg-[#111827] rounded-2xl p-6 border border-gray-800">
            <h3 className="text-gray-400">Skill Tests</h3>
            <p className="text-4xl font-bold mt-3">0</p>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
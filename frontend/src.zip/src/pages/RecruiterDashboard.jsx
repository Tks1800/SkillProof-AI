import DashboardLayout from "../layouts/DashboardLayout";
import {
  Briefcase,
  Users,
  CalendarDays,
  Award,
} from "lucide-react";

const cards = [
  {
    title: "Jobs Posted",
    value: "12",
    icon: <Briefcase size={30} />,
  },
  {
    title: "Applications",
    value: "84",
    icon: <Users size={30} />,
  },
  {
    title: "Interviews",
    value: "18",
    icon: <CalendarDays size={30} />,
  },
  {
    title: "Verified Hires",
    value: "7",
    icon: <Award size={30} />,
  },
];

export default function RecruiterDashboard() {
  return (
    <DashboardLayout>

      <div className="space-y-8">

        <div>
          <h1 className="text-4xl font-bold">
            Recruiter Dashboard
          </h1>

          <p className="text-gray-400 mt-2">
            Manage jobs, candidates and hiring.
          </p>
        </div>

        {/* Stats */}

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">

          {cards.map((card) => (

            <div
              key={card.title}
              className="bg-[#111827] rounded-2xl p-6 border border-gray-800 hover:border-cyan-500 transition"
            >

              <div className="flex justify-between items-center">

                <div>

                  <p className="text-gray-400">
                    {card.title}
                  </p>

                  <h2 className="text-4xl font-bold mt-3">
                    {card.value}
                  </h2>

                </div>

                <div className="text-cyan-400">
                  {card.icon}
                </div>

              </div>

            </div>

          ))}

        </div>

        {/* Coming Soon */}

        <div className="bg-[#111827] rounded-2xl border border-gray-800 p-8">

          <h2 className="text-2xl font-bold">
            Recent Activity
          </h2>

          <p className="text-gray-400 mt-4">
            Recruiter activity, job applications,
            AI candidate matching and interview
            invitations will appear here.
          </p>

        </div>

      </div>

    </DashboardLayout>
  );
}